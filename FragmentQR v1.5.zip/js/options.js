$(".version").append(chrome.runtime.getManifest().version);
